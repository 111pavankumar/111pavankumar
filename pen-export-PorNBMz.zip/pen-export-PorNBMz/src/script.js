// script.js
function appendToDisplay(value) {
  const display = document.getElementById("display");
  display.innerText += value;
  // Move the cursor to the end of the text
  const range = document.createRange();
  const sel = window.getSelection();
  range.selectNodeContents(display);
  range.collapse(false);
  sel.removeAllRanges();
  sel.addRange(range);
}

function clearDisplay() {
  document.getElementById("display").innerText = "";
}

function backspace() {
  const display = document.getElementById("display");
  let content = display.innerText;
  content = content.slice(0, -1);
  display.innerText = content;
}

function calculateResult() {
  try {
    let expression = document.getElementById("display").innerText;

    // Convert the power operator '^' to '**'
    expression = expression.replace(/\^/g, "**");

    // Convert sqrt to Math.sqrt
    expression = expression.replace(/sqrt\(/g, "Math.sqrt(");

    // Convert log10 and ln to JavaScript functions
    expression = expression.replace(/log10\(/g, "Math.log10(");
    expression = expression.replace(/ln\(/g, "Math.log(");

    // Convert trigonometric functions to JavaScript functions
    expression = expression.replace(/sin\(/g, "Math.sin(");
    expression = expression.replace(/cos\(/g, "Math.cos(");
    expression = expression.replace(/tan\(/g, "Math.tan(");

    // Convert other functions to JavaScript functions
    expression = expression.replace(/exp\(/g, "Math.exp(");
    expression = expression.replace(/ceil\(/g, "Math.ceil(");
    expression = expression.replace(/floor\(/g, "Math.floor(");

    // Convert other functions to JavaScript functions
    expression = expression.replace(/Math.PI/g, "Math.PI");
    expression = expression.replace(/Math.E/g, "Math.E");

    // Ensure trigonometric functions receive input in radians
    expression = expression.replace(/Math.sin\(/g, "Math.sin(Math.PI / 180 * ");
    expression = expression.replace(/Math.cos\(/g, "Math.cos(Math.PI / 180 * ");
    expression = expression.replace(/Math.tan\(/g, "Math.tan(Math.PI / 180 * ");

    // Validate expression to prevent dangerous operations
    if (/[^0-9+\-*/().^sincostanloglnexpceilfloorMathPIEe]/.test(expression)) {
      throw new Error("Invalid characters in expression");
    }

    // Evaluate the expression
    // Use Function constructor to evaluate expressions safely
    const result = new Function("return " + expression)();

    // Display result
    document.getElementById("display").innerText = result;
  } catch (error) {
    // Handle any errors that occur during evaluation
    document.getElementById("display").innerText = "Error";
  }
}
